Rem
Rem mk_accounts.sql
Rem
Rem	This script is called by clone_accounts.sql
Rem     Do not modify
Rem
Rem	Created  02/05/02 ahunold
Rem

UNDEFINE account
UNDEFINE password

PROMPT 
PROMPT specify account name as parameter 1:
DEFINE account     = &1
PROMPT 
PROMPT specify password as parameter 2:
DEFINE password    = &2
PROMPT 
PROMPT specify default tablespace as parameter 3:
DEFINE tbs         = &3
PROMPT
PROMPT specify temporary tablespace as parameter 4:
DEFINE temptbs     = &4
PROMPT

spool mk.&&account..log

DROP USER &&account CASCADE;

CREATE USER &&account IDENTIFIED BY &&password
 DEFAULT TABLESPACE &&tbs
 TEMPORARY TABLESPACE &&temptbs
 QUOTA UNLIMITED ON &&tbs;

GRANT create session
    , create table
    , create procedure
    , create sequence
    , create trigger
    , create view
    , create synonym
    , alter session
    , create type
    , create materialized view
    , query rewrite
    , create dimension
    , create any directory
    , alter user
    , resumable
    , ALTER ANY TABLE  -- These
    , DROP ANY TABLE   -- five are
    , LOCK ANY TABLE   -- needed
    , CREATE ANY TABLE -- to use
    , SELECT ANY TABLE -- DBMS_REDEFINITION
TO &&account;

GRANT select_catalog_role
    , execute_catalog_role
TO &&account;


REM  connect to user account and invoke the scripts that create schema objects.

CONNECT &&account/&&password

@?\rdbms\admin\utlxplan
@?\rdbms\admin\utldtree

@?\demo\schema\human_resources\hr_cre
@?\demo\schema\human_resources\hr_popul
@?\demo\schema\human_resources\hr_idx
@?\demo\schema\human_resources\hr_code
@?\demo\schema\human_resources\hr_comnt

@@oe_cre
@?\demo\schema\order_entry\oe_p_pi
@?\demo\schema\order_entry\oe_p_pd
@?\demo\schema\order_entry\oe_p_whs
@?\demo\schema\order_entry\oe_p_cus
@?\demo\schema\order_entry\oe_p_ord
@?\demo\schema\order_entry\oe_p_itm
@?\demo\schema\order_entry\oe_p_inv
@?\demo\schema\order_entry\oe_views
@?\demo\schema\order_entry\oe_idx

@@oc_cre
@?\demo\schema\order_entry\oc_popul
@?\demo\schema\order_entry\oc_comnt

@@pm_cre
host imp parfile=&&account..par

ALTER TABLE print_media 
  ADD ( CONSTRAINT printmedia_fk 
                   FOREIGN KEY (product_id) 
                   REFERENCES product_information(product_id) 
      ) ; 

EXECUTE dbms_utility.analyze_schema('&&account','COMPUTE');

@@CustomerStatus.sql


spool off
