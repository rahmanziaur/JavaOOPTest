prompt Adding Categories table


create table categories as select * from categories_tab;

alter table categories
 add constraint categories_pk1 primary key (category_id);

drop table categories_tab;


commit;

 
/