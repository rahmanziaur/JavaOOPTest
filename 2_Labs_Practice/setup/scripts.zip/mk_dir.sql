Rem
Rem $Header: mk_dir.sql 28-aug-2001.15:01:26 ahunold Exp $
Rem
Rem mk_dir.sql
Rem
Rem Copyright (c) 2001, Oracle Corporation.  All rights reserved.  
Rem
Rem    NAME
Rem      mk_dir.sql - Overwrites seed database directory objects
Rem
Rem    DESCRIPTION
Rem      The location of the Sample Schema directories are specific to
Rem      your Oracle installation. This script connects the directory
Rem      objects inside your demo database with the appropriate paths
Rem      in your file system.
Rem
Rem    NOTES
Rem      Needs password for SYSTEM as parameter 1
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    ahunold     08/28/01 - Merged ahunold_mk_dir
Rem    ahunold     08/28/01 - Created
Rem

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

PROMPT 
PROMPT specify password for SYSTEM as parameter 1:
DEFINE pwd_system = &1

CONNECT system/&pwd_system;

ALTER SESSION SET CURRENT_SCHEMA = SH;

CREATE OR REPLACE DIRECTORY data_file_dir AS 'D:\oracle\ora92\demo\schema\sales_history\'; 
CREATE OR REPLACE DIRECTORY log_file_dir  AS 'D:\oracle\ora92\demo\schema\log\'; 

ALTER SESSION SET CURRENT_SCHEMA = PM;

CREATE OR REPLACE DIRECTORY media_dir AS 'D:\oracle\ora92\demo\schema\product_media\';

GRANT READ ON DIRECTORY media_dir TO PUBLIC WITH GRANT OPTION;

