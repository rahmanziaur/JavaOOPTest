create or replace trigger insert_ord_id
  BEFORE INSERT ON orders
  FOR EACH ROW
DECLARE
    new_id number;
  BEGIN
    SELECT orders_seq.NextVal 
	 INTO new_id from Dual;
    :new.order_id := new_id;
  END;
/