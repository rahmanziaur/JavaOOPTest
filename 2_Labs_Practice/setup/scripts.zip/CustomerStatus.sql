prompt Adding status and discount columns...

alter table order_items add (
 discount_unit_price number(8,2)); 

update order_items set discount_unit_price = 
  (select list_price from product_information where 
  product_information.product_id = order_items.product_id);
 
alter table customers add ( 
 status varchar2(10)); 
 
update customers set status = 'Silver';

update customers set status = 'Gold' 
 where mod(customer_id, 4) = 0;

update customers set status = 'Platinum' 
 where mod(customer_id, 5) = 0;

commit;



prompt Adding Categories table


create table categories as select * from categories_tab;

alter table categories
 add constraint categories_pk1 primary key (category_id);

drop table categories_tab;


commit;

 
/
alter table product_information
add constraint product_info_category_fk foreign key (category_id) references categories (category_id);




prompt Adding orders trigger


create or replace trigger insert_ord_id
  BEFORE INSERT ON orders
  FOR EACH ROW
DECLARE
    new_id number;
  BEGIN
    SELECT orders_seq.NextVal 
	 INTO new_id from Dual;
    :new.order_id := new_id;
  END;
/