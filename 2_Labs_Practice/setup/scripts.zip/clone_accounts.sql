Rem
Rem    NAME
Rem      clone_accounts.sql - clones Sample Schema objects into ora1... accounts
Rem
Rem    DESCRIPTION
Rem      In classrooms, there is sometimes the need to make the Sample
Rem      Schemas objects available within a series of individual schemas
Rem      This script makes this cloning process easier.
Rem
Rem    NOTES
Rem      - All parameters needed can be modified here
Rem      - 
Rem    MODIFIED   (MM/DD/YY)
Rem      ahunold   02/05/02 - Created
Rem

SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 132
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 999
SET ECHO OFF
SET CONCAT '.'
COLUMN object_name     FORMAT A25
COLUMN subobject_name  FORMAT A25
COLUMN owner           FORMAT A10

Rem
Rem  parameter 1: schema owner
Rem  parameter 2: schema password
Rem  parameter 4: default tablespace
Rem  parameter 4: temp tablespace
Rem

--
-- BEGIN
--

CONNECT system/&&password_system
@@mk_account ORA1 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA2 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA3 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA4 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA5 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA6 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA7 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA8 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA9 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA10 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA11 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA12 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA13 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA14 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA15 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA16 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA17 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA18 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA19 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account ORA20 ORACLE USERS TEMP
CONNECT system/&&password_system
@@mk_account TEACH ORACLE USERS TEMP


--
-- END
--

CONNECT system/&&password_system

SPOOL verify_accounts.log


begin
dbms_stats.gather_table_stats(ownname=> 'ORA1', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA2', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA3', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA4', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA5', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA6', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA7', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA8', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA9', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA10', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA11', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA12', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA13', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA14', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA15', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA16', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA17', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA18', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA19', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'ORA20', tabname=> 'CATEGORIES', partname=> NULL);
end;
/
begin
dbms_stats.gather_table_stats(ownname=> 'TEACH', tabname=> 'CATEGORIES', partname=> NULL);
end;
/



SELECT  owner, object_type, status, count(*)
FROM dba_objects
WHERE owner like 'ORA%' 
AND object_name LIKE 'SYS%'
GROUP BY owner, object_type, status;

SELECT          owner, table_name, num_rows
 FROM           dba_tables
 WHERE owner like 'ORA%' 
 ORDER BY       2,1,3;

CONNECT ora1/oracle
@@verify_intermedia

SPOOL OFF
