README.txt
	last modification: ahunold 03/08/2002 Bug 1947899 solved 

Prerequisites:	
	9i database with Sample Schemas created
	Prerequisites for Sample Schemas met (use DBCA to do this):
		ORDINST and MDSYS users present
		Database JVM enabled
	250 MB space in tablespace USERS (tablespace should be EXTENT MANAGEMENT
	LOCAL AUTOALLOCATE and datafile should be AUTOEXTEND ON)

Procedure:
	1) Edit the file "clone_accounts.sql" and set the appropriate passwords,
	   tablespace names
	2) Start SQL*Plus, typing "sqlplus /nolog"
	3) Execute the account cloning script, typing "@clone_accounts.sql"
	   NOTE: Ignore warnings while importing

Possible problems:
	* Accounts HR. SH. PM or OE locked or passwords different from usernames
	* You tried to run this in a database that does not have the 9i Sample Schemas
	  properly set up
	* You are running this while a user ORAnn is connected
	* Your DIRECTORY objects don't work. (You get an error from running
	  verify_intermedia.sql from one of the ora<nn> accounts. 
          If that's the case, do:
	  - In 9.2 or later, run $ORACLE_HOME/demo/schema/mk_dir.sql as SYSTEM
	  - In 9.0.1, you need to:
	    1) 	Edit the mk_dir.sql provided in this ZIP. Change all references to
		E:\orant\ora901\demo\schema\ and replace them with the proper 
		path name for your system. Be careful to use "/" on UNIX and "\" on 
		Windows. Also make sure the strings end with "/" or "\".
	    2)	Copy the JPG files in this ZIP to $ORACLE_HOME/demo/schema/product_media/
	    3)  Run verify_intermedia.sql under ora1 once more. Should not return errors.

Verification
        check verify_accounts.log. It should look like this:


OWNER      OBJECT_TYPE        STATUS    COUNT(*)
---------- ------------------ ------- ----------
ORA1      LOB                VALID           22
ORA1      TYPE               VALID            5
ORA1      INDEX              VALID            5
ORA2      LOB                VALID           22
ORA2      TYPE               VALID            5
ORA2      INDEX              VALID            5
ORA3      LOB                VALID           22
ORA3      TYPE               VALID            5
ORA3      INDEX              VALID            5
ORA4      LOB                VALID           22
ORA4      TYPE               VALID            5
ORA4      INDEX              VALID            5
ORA5      LOB                VALID           22
ORA5      TYPE               VALID            5
ORA5      INDEX              VALID            5
ORA6      LOB                VALID           22
ORA6      TYPE               VALID            5
ORA6      INDEX              VALID            5
ORA7      LOB                VALID           22
ORA7      TYPE               VALID            5
ORA7      INDEX              VALID            5
ORA8      LOB                VALID           22
ORA8      TYPE               VALID            5
ORA8      INDEX              VALID            5
ORA9      LOB                VALID           22
ORA9      TYPE               VALID            5
ORA9      INDEX              VALID            5
ORA10      LOB                VALID           22
ORA10      TYPE               VALID            5
ORA10      INDEX              VALID            5
ORA11      LOB                VALID           22
ORA11      TYPE               VALID            5
ORA11      INDEX              VALID            5
ORA12      LOB                VALID           22
ORA12      TYPE               VALID            5
ORA12      INDEX              VALID            5
ORA13      LOB                VALID           22
ORA13      TYPE               VALID            5
ORA13      INDEX              VALID            5
ORA14      LOB                VALID           22
ORA14      TYPE               VALID            5
ORA14      INDEX              VALID            5
ORA15      LOB                VALID           22
ORA15      TYPE               VALID            5
ORA15      INDEX              VALID            5
ORA16      LOB                VALID           22
ORA16      TYPE               VALID            5
ORA16      INDEX              VALID            5
ORA17      LOB                VALID           22
ORA17      TYPE               VALID            5
ORA17      INDEX              VALID            5
ORA18      LOB                VALID           22
ORA18      TYPE               VALID            5
ORA18      INDEX              VALID            5
ORA19      LOB                VALID           22
ORA19      TYPE               VALID            5
ORA19      INDEX              VALID            5
ORA20      LOB                VALID           22
ORA20      TYPE               VALID            5
ORA20      INDEX              VALID            5

60 rows selected.


OWNER      TABLE_NAME                       NUM_ROWS
---------- ------------------------------ ----------
ORA1      COUNTRIES                              25
ORA2      COUNTRIES                              25
ORA3      COUNTRIES                              25
ORA4      COUNTRIES                              25
ORA5      COUNTRIES                              25
ORA6      COUNTRIES                              25
ORA7      COUNTRIES                              25
ORA8      COUNTRIES                              25
ORA9      COUNTRIES                              25
ORA10      COUNTRIES                              25
ORA11      COUNTRIES                              25
ORA12      COUNTRIES                              25
ORA13      COUNTRIES                              25
ORA14      COUNTRIES                              25
ORA15      COUNTRIES                              25
ORA16      COUNTRIES                              25
ORA17      COUNTRIES                              25
ORA18      COUNTRIES                              25
ORA19      COUNTRIES                              25
ORA20      COUNTRIES                              25
ORA1      CUSTOMERS                             319
ORA2      CUSTOMERS                             319
ORA3      CUSTOMERS                             319
ORA4      CUSTOMERS                             319
ORA5      CUSTOMERS                             319
ORA6      CUSTOMERS                             319
ORA7      CUSTOMERS                             319
ORA8      CUSTOMERS                             319
ORA9      CUSTOMERS                             319
ORA10      CUSTOMERS                             319
ORA11      CUSTOMERS                             319
ORA12      CUSTOMERS                             319
ORA13      CUSTOMERS                             319
ORA14      CUSTOMERS                             319
ORA15      CUSTOMERS                             319
ORA16      CUSTOMERS                             319
ORA17      CUSTOMERS                             319
ORA18      CUSTOMERS                             319
ORA19      CUSTOMERS                             319
ORA20      CUSTOMERS                             319
ORA1      DEPARTMENTS                            27
ORA2      DEPARTMENTS                            27
ORA3      DEPARTMENTS                            27
ORA4      DEPARTMENTS                            27
ORA5      DEPARTMENTS                            27
ORA6      DEPARTMENTS                            27
ORA7      DEPARTMENTS                            27
ORA8      DEPARTMENTS                            27
ORA9      DEPARTMENTS                            27
ORA10      DEPARTMENTS                            27
ORA11      DEPARTMENTS                            27
ORA12      DEPARTMENTS                            27
ORA13      DEPARTMENTS                            27
ORA14      DEPARTMENTS                            27
ORA15      DEPARTMENTS                            27
ORA16      DEPARTMENTS                            27
ORA17      DEPARTMENTS                            27
ORA18      DEPARTMENTS                            27
ORA19      DEPARTMENTS                            27
ORA20      DEPARTMENTS                            27
ORA1      DEPTREE_TEMPTAB                         0
ORA2      DEPTREE_TEMPTAB                         0
ORA3      DEPTREE_TEMPTAB                         0
ORA4      DEPTREE_TEMPTAB                         0
ORA5      DEPTREE_TEMPTAB                         0
ORA6      DEPTREE_TEMPTAB                         0
ORA7      DEPTREE_TEMPTAB                         0
ORA8      DEPTREE_TEMPTAB                         0
ORA9      DEPTREE_TEMPTAB                         0
ORA10      DEPTREE_TEMPTAB                         0
ORA11      DEPTREE_TEMPTAB                         0
ORA12      DEPTREE_TEMPTAB                         0
ORA13      DEPTREE_TEMPTAB                         0
ORA14      DEPTREE_TEMPTAB                         0
ORA15      DEPTREE_TEMPTAB                         0
ORA16      DEPTREE_TEMPTAB                         0
ORA17      DEPTREE_TEMPTAB                         0
ORA18      DEPTREE_TEMPTAB                         0
ORA19      DEPTREE_TEMPTAB                         0
ORA20      DEPTREE_TEMPTAB                         0
ORA1      EMPLOYEES                             107
ORA2      EMPLOYEES                             107
ORA3      EMPLOYEES                             107
ORA4      EMPLOYEES                             107
ORA5      EMPLOYEES                             107
ORA6      EMPLOYEES                             107
ORA7      EMPLOYEES                             107
ORA8      EMPLOYEES                             107
ORA9      EMPLOYEES                             107
ORA10      EMPLOYEES                             107
ORA11      EMPLOYEES                             107
ORA12      EMPLOYEES                             107
ORA13      EMPLOYEES                             107
ORA14      EMPLOYEES                             107
ORA15      EMPLOYEES                             107
ORA16      EMPLOYEES                             107
ORA17      EMPLOYEES                             107

OWNER      TABLE_NAME                       NUM_ROWS
---------- ------------------------------ ----------
ORA18      EMPLOYEES                             107
ORA19      EMPLOYEES                             107
ORA20      EMPLOYEES                             107
ORA1      INVENTORIES                          1112
ORA2      INVENTORIES                          1112
ORA3      INVENTORIES                          1112
ORA4      INVENTORIES                          1112
ORA5      INVENTORIES                          1112
ORA6      INVENTORIES                          1112
ORA7      INVENTORIES                          1112
ORA8      INVENTORIES                          1112
ORA9      INVENTORIES                          1112
ORA10      INVENTORIES                          1112
ORA11      INVENTORIES                          1112
ORA12      INVENTORIES                          1112
ORA13      INVENTORIES                          1112
ORA14      INVENTORIES                          1112
ORA15      INVENTORIES                          1112
ORA16      INVENTORIES                          1112
ORA17      INVENTORIES                          1112
ORA18      INVENTORIES                          1112
ORA19      INVENTORIES                          1112
ORA20      INVENTORIES                          1112
ORA1      JOBS                                   19
ORA2      JOBS                                   19
ORA3      JOBS                                   19
ORA4      JOBS                                   19
ORA5      JOBS                                   19
ORA6      JOBS                                   19
ORA7      JOBS                                   19
ORA8      JOBS                                   19
ORA9      JOBS                                   19
ORA10      JOBS                                   19
ORA11      JOBS                                   19
ORA12      JOBS                                   19
ORA13      JOBS                                   19
ORA14      JOBS                                   19
ORA15      JOBS                                   19
ORA16      JOBS                                   19
ORA17      JOBS                                   19
ORA18      JOBS                                   19
ORA19      JOBS                                   19
ORA20      JOBS                                   19
ORA1      JOB_HISTORY                            10
ORA2      JOB_HISTORY                            10
ORA3      JOB_HISTORY                            10
ORA4      JOB_HISTORY                            10
ORA5      JOB_HISTORY                            10
ORA6      JOB_HISTORY                            10
ORA7      JOB_HISTORY                            10
ORA8      JOB_HISTORY                            10
ORA9      JOB_HISTORY                            10
ORA10      JOB_HISTORY                            10
ORA11      JOB_HISTORY                            10
ORA12      JOB_HISTORY                            10
ORA13      JOB_HISTORY                            10
ORA14      JOB_HISTORY                            10
ORA15      JOB_HISTORY                            10
ORA16      JOB_HISTORY                            10
ORA17      JOB_HISTORY                            10
ORA18      JOB_HISTORY                            10
ORA19      JOB_HISTORY                            10
ORA20      JOB_HISTORY                            10
ORA1      LOCATIONS                              23
ORA2      LOCATIONS                              23
ORA3      LOCATIONS                              23
ORA4      LOCATIONS                              23
ORA5      LOCATIONS                              23
ORA6      LOCATIONS                              23
ORA7      LOCATIONS                              23
ORA8      LOCATIONS                              23
ORA9      LOCATIONS                              23
ORA10      LOCATIONS                              23
ORA11      LOCATIONS                              23
ORA12      LOCATIONS                              23
ORA13      LOCATIONS                              23
ORA14      LOCATIONS                              23
ORA15      LOCATIONS                              23
ORA16      LOCATIONS                              23
ORA17      LOCATIONS                              23
ORA18      LOCATIONS                              23
ORA19      LOCATIONS                              23
ORA20      LOCATIONS                              23
ORA1      ONLINE_MEDIA                            9
ORA2      ONLINE_MEDIA                            9
ORA3      ONLINE_MEDIA                            9
ORA4      ONLINE_MEDIA                            9
ORA5      ONLINE_MEDIA                            9
ORA6      ONLINE_MEDIA                            9
ORA7      ONLINE_MEDIA                            9
ORA8      ONLINE_MEDIA                            9
ORA9      ONLINE_MEDIA                            9
ORA10      ONLINE_MEDIA                            9
ORA11      ONLINE_MEDIA                            9
ORA12      ONLINE_MEDIA                            9
ORA13      ONLINE_MEDIA                            9
ORA14      ONLINE_MEDIA                            9

OWNER      TABLE_NAME                       NUM_ROWS
---------- ------------------------------ ----------
ORA15      ONLINE_MEDIA                            9
ORA16      ONLINE_MEDIA                            9
ORA17      ONLINE_MEDIA                            9
ORA18      ONLINE_MEDIA                            9
ORA19      ONLINE_MEDIA                            9
ORA20      ONLINE_MEDIA                            9
ORA1      ORDERS                                105
ORA2      ORDERS                                105
ORA3      ORDERS                                105
ORA4      ORDERS                                105
ORA5      ORDERS                                105
ORA6      ORDERS                                105
ORA7      ORDERS                                105
ORA8      ORDERS                                105
ORA9      ORDERS                                105
ORA10      ORDERS                                105
ORA11      ORDERS                                105
ORA12      ORDERS                                105
ORA13      ORDERS                                105
ORA14      ORDERS                                105
ORA15      ORDERS                                105
ORA16      ORDERS                                105
ORA17      ORDERS                                105
ORA18      ORDERS                                105
ORA19      ORDERS                                105
ORA20      ORDERS                                105
ORA1      ORDER_ITEMS                           665
ORA2      ORDER_ITEMS                           665
ORA3      ORDER_ITEMS                           665
ORA4      ORDER_ITEMS                           665
ORA5      ORDER_ITEMS                           665
ORA6      ORDER_ITEMS                           665
ORA7      ORDER_ITEMS                           665
ORA8      ORDER_ITEMS                           665
ORA9      ORDER_ITEMS                           665
ORA10      ORDER_ITEMS                           665
ORA11      ORDER_ITEMS                           665
ORA12      ORDER_ITEMS                           665
ORA13      ORDER_ITEMS                           665
ORA14      ORDER_ITEMS                           665
ORA15      ORDER_ITEMS                           665
ORA16      ORDER_ITEMS                           665
ORA17      ORDER_ITEMS                           665
ORA18      ORDER_ITEMS                           665
ORA19      ORDER_ITEMS                           665
ORA20      ORDER_ITEMS                           665
ORA1      PLAN_TABLE                              0
ORA2      PLAN_TABLE                              0
ORA3      PLAN_TABLE                              0
ORA4      PLAN_TABLE                              0
ORA5      PLAN_TABLE                              0
ORA6      PLAN_TABLE                              0
ORA7      PLAN_TABLE                              0
ORA8      PLAN_TABLE                              0
ORA9      PLAN_TABLE                              0
ORA10      PLAN_TABLE                              0
ORA11      PLAN_TABLE                              0
ORA12      PLAN_TABLE                              0
ORA13      PLAN_TABLE                              0
ORA14      PLAN_TABLE                              0
ORA15      PLAN_TABLE                              0
ORA16      PLAN_TABLE                              0
ORA17      PLAN_TABLE                              0
ORA18      PLAN_TABLE                              0
ORA19      PLAN_TABLE                              0
ORA20      PLAN_TABLE                              0
ORA1      PRINT_MEDIA                             4
ORA2      PRINT_MEDIA                             4
ORA3      PRINT_MEDIA                             4
ORA4      PRINT_MEDIA                             4
ORA5      PRINT_MEDIA                             4
ORA6      PRINT_MEDIA                             4
ORA7      PRINT_MEDIA                             4
ORA8      PRINT_MEDIA                             4
ORA9      PRINT_MEDIA                             4
ORA10      PRINT_MEDIA                             4
ORA11      PRINT_MEDIA                             4
ORA12      PRINT_MEDIA                             4
ORA13      PRINT_MEDIA                             4
ORA14      PRINT_MEDIA                             4
ORA15      PRINT_MEDIA                             4
ORA16      PRINT_MEDIA                             4
ORA17      PRINT_MEDIA                             4
ORA18      PRINT_MEDIA                             0
ORA19      PRINT_MEDIA                             4
ORA20      PRINT_MEDIA                             4
ORA1      PRODUCT_DESCRIPTIONS                 8640
ORA2      PRODUCT_DESCRIPTIONS                 8640
ORA3      PRODUCT_DESCRIPTIONS                 8640
ORA4      PRODUCT_DESCRIPTIONS                 8640
ORA5      PRODUCT_DESCRIPTIONS                 8640
ORA6      PRODUCT_DESCRIPTIONS                 8640
ORA7      PRODUCT_DESCRIPTIONS                 8640
ORA8      PRODUCT_DESCRIPTIONS                 8640
ORA9      PRODUCT_DESCRIPTIONS                 8640
ORA10      PRODUCT_DESCRIPTIONS                 8640
ORA11      PRODUCT_DESCRIPTIONS                 8640

OWNER      TABLE_NAME                       NUM_ROWS
---------- ------------------------------ ----------
ORA12      PRODUCT_DESCRIPTIONS                 8640
ORA13      PRODUCT_DESCRIPTIONS                 8640
ORA14      PRODUCT_DESCRIPTIONS                 8640
ORA15      PRODUCT_DESCRIPTIONS                 8640
ORA16      PRODUCT_DESCRIPTIONS                 8640
ORA17      PRODUCT_DESCRIPTIONS                 8640
ORA18      PRODUCT_DESCRIPTIONS                 8640
ORA19      PRODUCT_DESCRIPTIONS                 8640
ORA20      PRODUCT_DESCRIPTIONS                 8640
ORA1      PRODUCT_INFORMATION                   288
ORA2      PRODUCT_INFORMATION                   288
ORA3      PRODUCT_INFORMATION                   288
ORA4      PRODUCT_INFORMATION                   288
ORA5      PRODUCT_INFORMATION                   288
ORA6      PRODUCT_INFORMATION                   288
ORA7      PRODUCT_INFORMATION                   288
ORA8      PRODUCT_INFORMATION                   288
ORA9      PRODUCT_INFORMATION                   288
ORA10      PRODUCT_INFORMATION                   288
ORA11      PRODUCT_INFORMATION                   288
ORA12      PRODUCT_INFORMATION                   288
ORA13      PRODUCT_INFORMATION                   288
ORA14      PRODUCT_INFORMATION                   288
ORA15      PRODUCT_INFORMATION                   288
ORA16      PRODUCT_INFORMATION                   288
ORA17      PRODUCT_INFORMATION                   288
ORA18      PRODUCT_INFORMATION                   288
ORA19      PRODUCT_INFORMATION                   288
ORA20      PRODUCT_INFORMATION                   288
ORA1      PRODUCT_REF_LIST_NESTEDTAB            288
ORA2      PRODUCT_REF_LIST_NESTEDTAB            288
ORA3      PRODUCT_REF_LIST_NESTEDTAB            288
ORA4      PRODUCT_REF_LIST_NESTEDTAB            288
ORA5      PRODUCT_REF_LIST_NESTEDTAB            288
ORA6      PRODUCT_REF_LIST_NESTEDTAB            288
ORA7      PRODUCT_REF_LIST_NESTEDTAB            288
ORA8      PRODUCT_REF_LIST_NESTEDTAB            288
ORA9      PRODUCT_REF_LIST_NESTEDTAB            288
ORA10      PRODUCT_REF_LIST_NESTEDTAB            288
ORA11      PRODUCT_REF_LIST_NESTEDTAB            288
ORA12      PRODUCT_REF_LIST_NESTEDTAB            288
ORA13      PRODUCT_REF_LIST_NESTEDTAB            288
ORA14      PRODUCT_REF_LIST_NESTEDTAB            288
ORA15      PRODUCT_REF_LIST_NESTEDTAB            288
ORA16      PRODUCT_REF_LIST_NESTEDTAB            288
ORA17      PRODUCT_REF_LIST_NESTEDTAB            288
ORA18      PRODUCT_REF_LIST_NESTEDTAB            288
ORA19      PRODUCT_REF_LIST_NESTEDTAB            288
ORA20      PRODUCT_REF_LIST_NESTEDTAB            288
ORA1      REGIONS                                 4
ORA2      REGIONS                                 4
ORA3      REGIONS                                 4
ORA4      REGIONS                                 4
ORA5      REGIONS                                 4
ORA6      REGIONS                                 4
ORA7      REGIONS                                 4
ORA8      REGIONS                                 4
ORA9      REGIONS                                 4
ORA10      REGIONS                                 4
ORA11      REGIONS                                 4
ORA12      REGIONS                                 4
ORA13      REGIONS                                 4
ORA14      REGIONS                                 4
ORA15      REGIONS                                 4
ORA16      REGIONS                                 4
ORA17      REGIONS                                 4
ORA18      REGIONS                                 4
ORA19      REGIONS                                 4
ORA20      REGIONS                                 4
ORA1      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA2      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA3      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA4      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA5      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA6      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA7      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA8      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA9      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA10      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA11      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA12      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA13      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA14      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA15      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA16      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA17      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA18      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA19      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA20      SUBCATEGORY_REF_LIST_NESTEDTAB         21
ORA1      WAREHOUSES                              9
ORA2      WAREHOUSES                              9
ORA3      WAREHOUSES                              9
ORA4      WAREHOUSES                              9
ORA5      WAREHOUSES                              9
ORA6      WAREHOUSES                              9
ORA7      WAREHOUSES                              9
ORA8      WAREHOUSES                              9

OWNER      TABLE_NAME                       NUM_ROWS
---------- ------------------------------ ----------
ORA9      WAREHOUSES                              9
ORA10      WAREHOUSES                              9
ORA11      WAREHOUSES                              9
ORA12      WAREHOUSES                              9
ORA13      WAREHOUSES                              9
ORA14      WAREHOUSES                              9
ORA15      WAREHOUSES                              9
ORA16      WAREHOUSES                              9
ORA17      WAREHOUSES                              9
ORA18      WAREHOUSES                              9
ORA19      WAREHOUSES                              9
ORA20      WAREHOUSES                              9

400 rows selected.

Connected.

PL/SQL procedure successfully completed.

