DECLARE
  img ordsys.ordimage;
  ctx raw(64);
BEGIN
  SELECT product_photo INTO img FROM online_media WHERE product_id = '2400' FOR UPDATE;
  img.import(ctx);
  UPDATE online_media SET product_photo=img WHERE product_id = '2400';
END;
/

